# patch-cloud annotation for react@19.3.0

Upstream package from registry.npmjs.org, repacked with metadata only.

- **Fork:** fitzyracing1/react
- **Branch:** main
- **PR:** none yet

No code changes yet: this is upstream react, repacked with patch-cloud metadata only.
